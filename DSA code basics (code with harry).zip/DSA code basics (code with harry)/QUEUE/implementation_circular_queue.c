#include<stdio.h>
#include<stdlib.h>
struct circularQueue{
    int size;
    int *arr;
    int f;
    int r;
};
int isempty(struct circularQueue *q){
    if(q->f==q->r){
        return 1;
    }
    return 0;
}
int isfull(struct circularQueue *q){
    if((q->r+1)%q->size== q->f){
        return 1;
    }
    return 0;
}
void enqueue(struct circularQueue * q , int val){
    if(isfull(q)){
        printf("The queue is full\n");
    }
    else{
        q->r= (q->r+1)%q->size;
        q->arr[q->r]=val;
        printf("The element is queued: %d\n",val);
    }
}
int dequeue(struct circularQueue *q){
    int a =-1;
    if(isempty(q)){
        printf("The queue is full\n");
    }
    else{
        q->f= (q->f + 1)%q->size;
        a=q->arr[q->f];
    }
    return a;
}


int main(){
struct circularQueue q;
q.size=4;
q.f=q.r=0;  //This is different from linear queue in linear queue we use f=r=-1
q.arr=(int *)malloc(q.size*sizeof(int));
 return 0;
}