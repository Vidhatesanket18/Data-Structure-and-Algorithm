#include<conio.h>
#include<stdio.h>

struct node {
    int data;
   struct node * left, *right;
    int ht;
    struct node *father;
};
int height(struct node *T){
    int lh,rh;
    if (T==NULL)
    {
        return(0);
        if (T->left==NULL)
        {
            lh=0;
        }
        else
        {
            lh=1+T->left->ht;
            if (T->right==NULL)
            {
                rh=0;
            }
            else
            {
                rh=1+T->right->ht;
            }
            if (lh>rh)
            {
                return(lh);
                
            }
            else
            {
                return (rh);
            }
            
            int node*rotateright(struct node *x){
                node *y;
                y=x->left;
                x->left=y->right;
                y->right=x;
                x->ht=height(x);
                y->ht=height(y);
                return(y);
            }
            node *rotateleft(node *x){
                node *y;
                y=x->right;
                x->right=y->left;
                y->left=x;
                x->ht=height(x);
                y->ht=height(y);
                return (y);
            }
            node *RR(node *T){
                T=rotateleft(T);
                return (T);
            }
            node *LL(node *T){
                T=rotateright(T);
                return(T);
            }
            node *LR(node *T){
                T->left=rotateleft(T->left);
                T=rotateright(T);
                return (T);
            }
            
            
        }
        
        
    }
    
}