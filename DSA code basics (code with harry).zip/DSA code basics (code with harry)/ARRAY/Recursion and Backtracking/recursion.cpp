#include <iostream>
using namespace std;
int main(){
    string cars[4]={"volvo" ,"BMW" , "Maruti" , "Brezza"};
    cout<<cars[0];
    return 0;
}