#include<stdio.h>

int main(){
    int n = 2343;
    int  * a ;
    int ** b ;
    a = &n;
    b = &a;
    printf("The value of a %d\n", &n);
    printf("the address of n is %d\n", a);
    printf("The address of a is: %d\n" , b);
    printf("The value of *a is %d\n", *a);
    printf("The value of pointe is %d\n", **b);
}