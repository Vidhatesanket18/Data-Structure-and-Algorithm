#include<stdio.h>
int linearSearch(int arr[] , int size, int element){
    for(int i= 0; i<size; i++){
        if(arr[i]==element){
            return i;
        }
    }
    return -1;
}
int main(){
    int a[] ={23,34,3,43,34,56,7,67};
    int s = sizeof(a)/sizeof(int);
    int e = 56;
    int searchIndex = linearSearch(a, s, e);
    printf("The element %d was found at index %d  \n", e, searchIndex);
    





    return 0;
}