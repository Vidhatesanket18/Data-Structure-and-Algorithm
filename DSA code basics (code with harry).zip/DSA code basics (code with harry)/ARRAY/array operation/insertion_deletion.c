#include<stdio.h>
void printmsg(){
    printf("It is a void function");
}
int main(){
    printmsg();
   return 0;
}
