#include<stdio.h>
char stack[20];
int top= -1;
void push(char  x){
    stack[++top]=x;
    }

int main(){



    return 0;
}