#include <stdio.h>
#include <stdlib.h>

//Initialization of queue

 /*struct queue q;
 q.size=400;
 q.f=q.r=0;
 q.arr=(int *)malloc(q.size*sizeof(int)); */   //Initialization of queue and dynamically assign it a memory
struct queue
{
    int size;
    int f;
    int r;
    int *arr;
};

//checking whether queue is empty
int isEmpty(struct queue *q)
{
    if (q->r == q->f)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
//checking whether queue is full
int isFull(struct queue *q)
{
    if (q->r == q->size - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
//Inserting the element if there is empty space
void enqueue(struct queue *q, int val)
{
    if (isFull(q))
    {
        printf("This Queue is full\n");
    }
    else
    {
        q->r++;
        q->arr[q->r] = val;
    }
}

//Deleting the element if there is element
//we first enqueue 
int dequeue(struct queue *q)
{
    int a = -1;
    if (isEmpty(q))
    {
        printf("This Queue is empty\n");
    }
    else
    {
        q->f++;
        a = q->arr[q->f];
    }
}

int main()
{
    struct queue q;
    q.size = 400;
    q.f = q.r = 0;
    q.arr = (int *)malloc(q.size * sizeof(int));
    int node;
    int j = 0;
    int visited[7] = {0, 0, 0, 0, 0, 0, 0};

    //Defining graph using adjacency matrix
    //  0 ---> denotes the values corresponding unvisited array
    // 1---> denotes the value corresponding to node if visited 
    int a[7][7] = {
        {0, 1, 1, 1, 0, 0, 0},
        {1, 0, 1, 0, 0, 0, 0},
        {1, 1, 0, 1, 1, 0, 0},
        {1, 0, 1, 0, 1, 0, 0},
        {0, 0, 1, 1, 0, 1, 1},
        {0, 0, 0, 0, 1, 0, 0},
        {0, 0, 0, 0, 1, 0, 0},
    };
    printf("%d", j);
    visited[j] = 1;
    enqueue(&q, j);
    while (!isEmpty(&q))
    {
        int node = dequeue(&q);
        for (int i = 0; i < 7; i++)
        {
            if (a[node][i] == 1 && visited[i] == 0)
            {
                printf("%d\t", i);
                visited[i] = 1;
                enqueue(&q, i);
            }
        }
    }

    return 0;
}