#include <stdio.h>
#include <stdlib.h>
int main()
{
    int pos, i = 1;
    int count;

    

    struct node
    {
        int data;
        struct node *next;
    };
    struct node *head, *newnode, *temp; +

    newnode = (struct node *)malloc(sizeof(struct node));
    printf("Enter the position\n");
    scanf("%d", &pos);
    if (pos > count)
    {
        printf("Invalid position\n");
    }
    else
    {
        temp = head;
        while (i < pos)
        {
            temp = temp->next;
            i++;
        }
        printf("Enter data:\n");
        scanf("%d", &newnode->data);
        newnode->next = temp->next;
        temp->next = newnode;
    }

    return 0;
}