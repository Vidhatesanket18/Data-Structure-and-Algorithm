#include<stdio.h> 
 struct node{
        int data;
        struct node *next;
    
    };

    int main(){
  
    return 0;
}