#include<stdio.h>

int main(){

    struct node{
        int data; 
        struct node * next, *head, *temp;
    };                                                                                                                                                                                                                                                                                                                                                                           
    struct node * head;
    DeletefromBeg(){
        struct node * temp;
        temp =head;
        head=head->next;
        free(temp);
    }                             
                                                                                                                                                  
    return 0;
}

