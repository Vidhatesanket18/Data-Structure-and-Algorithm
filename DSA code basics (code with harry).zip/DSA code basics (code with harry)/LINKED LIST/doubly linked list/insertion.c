#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
};
void linkedListTraversal(struct node *head)
{
    struct node *ptr = head;
    do
    {
        printf("The element is%d\n", ptr->data);
        ptr = ptr->next;
    } while (ptr != head);
}
struct node *insertAtFirst(struct node *head, int data)
{
    struct node *ptr = (struct node *)malloc(sizeof(struct node));
    ptr->data = data;
    struct node *p = head->next;
    while (p->next != head)
    {
        p = p->next;
    }
    p->next = ptr;
    ptr->next = head;
    head = ptr;
    return head;
}

int main()
{
    struct node *head, *second, *third, *fourth;
    head = (struct node *)malloc(sizeof(struct node));
    second = (struct node *)malloc(sizeof(struct node));
    third = (struct node *)malloc(sizeof(struct node));
    fourth = (struct node *)malloc(sizeof(struct node));

    head ->data=23;
    head->next = second;

    second->data=234;
    second ->next = third;

    third ->data=234234;
    third ->next = fourth;

    fourth ->data=7987;
    fourth->next = head;

    printf("Circular linked list before insertion is \n");
    linkedListTraversal(head);

    head = insertAtFirst(head, 42);
    head = insertAtFirst(head, 560);
    head = insertAtFirst(head, 56);
    printf("Circular linked list after insertion is \n");
    linkedListTraversal(head);
    return 0;
}