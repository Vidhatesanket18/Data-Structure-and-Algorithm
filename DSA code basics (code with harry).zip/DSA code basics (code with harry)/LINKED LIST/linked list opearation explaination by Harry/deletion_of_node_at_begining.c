#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *ptr
};
void linkedListTraversal(struct node *n)
{
    while (n != NULL)
    {
        printf("Elements:%d\n", n->data);
        n = n->ptr;
    }
    
}
struct node * deleteFirstNode(struct node *head){
   struct node *p  = head;
    head = head->ptr;
    free (p);
    return (head);
}
int main()
{
    struct node *head, *first, *second, *third;
    head = (struct node *)malloc(sizeof(struct node));
    first = (struct node *)malloc(sizeof(struct node));
    second = (struct node *)malloc(sizeof(struct node));
    third = (struct node *)malloc(sizeof(struct node));

    head->data = 23;
    head->ptr = second;

    second->data = 64;
    second->ptr = third;

    third->data = 555;
    third->ptr = NULL;
    printf("The linked list before deleting node is:\n");
    linkedListTraversal(head);
    head = deleteFirstNode(head);
    printf("Linked list after deleting node is:\n");
    linkedListTraversal(head);


    return 0;
}