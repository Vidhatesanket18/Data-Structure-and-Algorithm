#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
};
// struct node insertionAtEnd(struct node * next, )
void linkedListTraversal(struct node * ptr){
    while(ptr !=NULL){
        printf("Element:%d\n", *ptr);
        ptr = ptr ->next;
    }
}

int main()
{
    struct node *head;
    struct node *first;
    struct node *second;
    struct node *third;

    head = (struct node *)malloc(sizeof(struct node));
    first = (struct node *)malloc(sizeof(struct node));
    second =(struct node *)malloc(sizeof(struct node));
    third =(struct node *)malloc(sizeof(struct node));

    head ->data= 23;
    head ->next = first;
     
    first ->data = 79;
    first ->next =second;

    second ->data= 54;
    second -> next = third;
     
    third -> data = 254;
    third -> next = NULL;

    linkedListTraversal(head);

    return 0;
}