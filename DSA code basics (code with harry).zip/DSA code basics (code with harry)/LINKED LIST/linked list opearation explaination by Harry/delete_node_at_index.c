#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
};
void linkedListTraversal(struct node *n)
{
    while (n != NULL)
    {
        printf("Elements:%d\n", n->data);
        n = n->next;
    }
    struct node *deleteAtIndex(struct node * head, int index)
    {
        struct node *p = head;
        struct node *q = head->next;
    }
    for (int i = 0; i < index - 1; i++)
    {
        p = p->next;
        q = q->next;
    }
    p->next = q->next;
    free(q);
    return head;
}

int main()
{
    struct node *head, *first, *second, *third;
    head = (struct node *)malloc(sizeof(struct node));
    second = (struct node *)malloc(sizeof(struct node));
    third = (struct node *)malloc(sizeof(struct node));

    head->data = 334;
    head->next = first;

    first->data = 45;
    first->next = second;

    second->data = 533;
    second->next = third;

    third->data = 457;
    third->next = NULL;

    linkedListTraversal(head);

    return 0;
}