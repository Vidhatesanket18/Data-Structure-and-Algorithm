#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
};
void printlist(struct node *n)
{
    while (n != NULL)
    {
        printf("Elements:%d\n", n->data);
        n = n->next;
    }

}
struct node *insertAtFirst(struct node *head, int data){
    struct node * new_node = (struct node *)malloc(sizeof(struct node));
    new_node ->data= data;
    new_node-> next = head;
    head = new_node;
}

int main()
{
    struct node *head;
    struct node *second;
    struct node *third;
    struct node *fourth;

    head = (struct node *)malloc(sizeof(struct node));
    second = (struct node *)malloc(sizeof(struct node));
    third = (struct node *)malloc(sizeof(struct node));
    fourth = (struct node *)malloc(sizeof(struct node));

    head->data = 23;
    head->next = second;

    second->data = 234;
    second->next = third;

    

    third->data = 33;
    third->next = NULL;

    printlist(head);
    head=insertAtFirst(head, 64);
    printf("This is a printlist of linked list after insertion complete\n");
    printlist(head);


    return 0;
}