public class fibonacci{
    public static void fibnum(int a , int b , int n){
        if (n==0){
            return;
        }
        
        int c = a + b;
    }
    public static void main(String args[])


}